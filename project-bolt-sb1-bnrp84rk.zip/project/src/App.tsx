import React from 'react';
import {
  Phone,
  Mail,
  MessageCircle,
  Facebook,
  Instagram,
  Download,
  MapPin,
} from 'lucide-react';
import BookingForm from './components/BookingForm';
import Map from './components/Map';

function App() {
  const profileData = {
    name: 'John Doe',
    position: 'Senior Software Engineer',
    photo: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    phone: '+1 (555) 123-4567',
    email: 'john.doe@example.com',
    whatsapp: '+15551234567',
    facebook: 'johndoe',
    instagram: '@johndoe',
    location: {
      latitude: 40.7128,
      longitude: -74.0060,
      address: '123 Business Street, New York, NY 10001',
    },
  };

  const handleSaveContact = () => {
    const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${profileData.name}
TITLE:${profileData.position}
TEL:${profileData.phone}
EMAIL:${profileData.email}
ADR:;;${profileData.location.address};;;
END:VCARD`;

    const blob = new Blob([vcard], { type: 'text/vcard' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${profileData.name.replace(' ', '_')}.vcf`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto p-6 space-y-8">
        {/* Profile Section */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="relative h-32 bg-gradient-to-r from-blue-500 to-blue-600" />
          <div className="relative px-6 pb-6">
            <div className="flex justify-center">
              <img
                src={profileData.photo}
                alt={profileData.name}
                className="w-32 h-32 rounded-full border-4 border-white absolute -top-16"
              />
            </div>
            <div className="mt-16 text-center">
              <h1 className="text-2xl font-bold text-gray-900">{profileData.name}</h1>
              <p className="text-gray-600">{profileData.position}</p>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-white rounded-xl shadow-md p-6 space-y-4">
          <div className="flex items-center space-x-3">
            <Phone className="h-5 w-5 text-blue-500" />
            <a href={`tel:${profileData.phone}`} className="text-gray-700">{profileData.phone}</a>
          </div>
          <div className="flex items-center space-x-3">
            <Mail className="h-5 w-5 text-blue-500" />
            <a href={`mailto:${profileData.email}`} className="text-gray-700">{profileData.email}</a>
          </div>
          <div className="flex items-center space-x-3">
            <MessageCircle className="h-5 w-5 text-blue-500" />
            <a href={`https://wa.me/${profileData.whatsapp}`} target="_blank" rel="noopener noreferrer" className="text-gray-700">WhatsApp</a>
          </div>
          <div className="flex items-center space-x-3">
            <Facebook className="h-5 w-5 text-blue-500" />
            <a href={`https://facebook.com/${profileData.facebook}`} target="_blank" rel="noopener noreferrer" className="text-gray-700">Facebook</a>
          </div>
          <div className="flex items-center space-x-3">
            <Instagram className="h-5 w-5 text-blue-500" />
            <a href={`https://instagram.com/${profileData.instagram}`} target="_blank" rel="noopener noreferrer" className="text-gray-700">Instagram</a>
          </div>
          <button
            onClick={handleSaveContact}
            className="w-full mt-4 flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
          >
            <Download className="h-4 w-4 mr-2" />
            Save My Contact
          </button>
        </div>

        {/* Location */}
        <div className="bg-white rounded-xl shadow-md p-6 space-y-4">
          <div className="flex items-center space-x-2 mb-4">
            <MapPin className="h-5 w-5 text-blue-500" />
            <h2 className="text-lg font-semibold">Location</h2>
          </div>
          <p className="text-gray-600 mb-4">{profileData.location.address}</p>
          <Map {...profileData.location} />
        </div>

        {/* Booking System */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Schedule a Meeting</h2>
          <BookingForm />
        </div>
      </div>
    </div>
  );
}

export default App;