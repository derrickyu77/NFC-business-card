export interface BookingFormData {
  date: string;
  time: string;
  description: string;
  email: string;
}

export interface MapProps {
  latitude: number;
  longitude: number;
  address: string;
}